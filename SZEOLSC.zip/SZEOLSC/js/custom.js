$('.input-search').hide();
$('.search-button').on('click', function () {
$('.input-search').fadeToggle();
});